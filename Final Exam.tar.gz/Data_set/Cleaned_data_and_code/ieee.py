
# for getting skill but only once i.e. to know the names of the skills 
import csv
import json
from pprint import pprint
import re
new_list=[]
with open('/home/madhav/Desktop/D5.csv','rb') as f:
    	reader = csv.reader(f,delimiter=' ')
    	skill=[]	
	for x in reader:
		skill.append(x[0])	

	ls=[]
	#listnum=[]
	#count=0
	#x=0
	tr=3 in [3,4,5]
	fa=3 in [4,5,6]
	#print ls
	for y in skill:
		#print 'skill name',y
		inp="".join(y.split())
		#print 'space removed',inp
		#while x!=len(ls):
		temp=inp not in ls
		if temp==tr:
			ls.append(inp)
			#listnum.append(inp,count)
		#else:
			#temp1=inp in list num			
			
			#print ls
		#x+=1

		#print "**************************************************************************"
	print(ls)
	with open("D55.csv", "w") as f:
		writer = csv.writer(f, delimiter=',')
		writer.writerow(ls)

'''
	csvfile = open('Automation Test Engineer.csv', 'r')
	jsonfile = open('file.json', 'w')

	#fieldnames = ("FirstName","LastName","IDNumber","Message")
	reader = csv.DictReader(csvfile)
	for row in reader:
	    json.dump(row, jsonfile)
	    jsonfile.write('\n')

'''




'''	
ls=['Hi','AB']
ls1=['hi','ab','cd']
x=0;
for y in ls:
	
	print y
	print ls1
	pr=y.lower() in ls1[x].lower()
	x+=1
	print x
	print pr

'''
