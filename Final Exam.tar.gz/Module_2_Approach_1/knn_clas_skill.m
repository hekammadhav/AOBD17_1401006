tic
x=randi([0,10],100,100);
R = zeros(100,100);
for i=1:100
    for j=1:100
        if x(i,j)>0
        R(i,j)=1;
        else
        R(i,j)=0;
        end
    end
end
cnt=0;
for k=1:100
sam=x(81:100,k);
train=x(1:80,k);
group=R(1:80,k);

class = knnclassify(sam, train, group,4);


norm_s(1:20,k)=R(81:100,1)-class;
for ad=1:20
if norm_s(ad,k)==0
    cnt=cnt+1;
    
end
end


end

gscatter(train(:,1),train(:,2),group,'rb','+x');
legend('Training group 1', 'Training group 2');


disp(100-(cnt/100));


toc